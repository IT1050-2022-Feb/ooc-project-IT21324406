class Pharmacist : public Employee
{
  private:
    int pharmacistId;
    int rate;
    int days;

  public:
    Pharmacist();
    Pharmacist(int pharmId,char eName[],char eEmail[],int eCno);
    void displayDetails();
    void addProducts();
    void prepareOrders();
    void calcSalary(int r,int d);
    double displaySalary();
     ~ Pharmacist();
    };