#include "Pharmacist.h"
#include"Employee.h"

Pharmacist::Pharmacist(int pharmId,char eName[],char eEmail[],int eCno) : Employee(eName,eEmail,eCno)
{
  pharmacistId = pharmId;
 
}
void Pharmacist::displayDetails()
{
}
void Pharmacist::addProducts()
{
}
void Pharmacist::prepareOrders()
{
}
void Pharmacist::calcSalary(int r,int d)
{
  rate = r;
  days = d;
}
double Pharmacist::displaySalary()
{
}
Pharmacist::~Pharmacist()
{
}