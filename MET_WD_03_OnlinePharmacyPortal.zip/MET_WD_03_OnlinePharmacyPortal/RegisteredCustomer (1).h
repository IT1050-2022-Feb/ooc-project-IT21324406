class RegisteredCustomer
{
private:
   
   int customerId;
   char customerName[50];
   char address[50];
   int phone;
   char email[50];
   int noOfCustomer;
   Order *order[SIZE];
   Feedback *feedbackId[SIZE];
   

public:

   ResteredCustomer()
   RegisteredCustomer(char cusName[], int cusId);
   void setDetails(char cAdd[],int cPho,char cEmail[]);
   int getDetails();
   void addOrder(Order *o);
   void login();
   void logout();
   void searchProducts();
   void displayDetails();
   void displayfeedbackId();
   ~ RegisteredCustomer();
};
