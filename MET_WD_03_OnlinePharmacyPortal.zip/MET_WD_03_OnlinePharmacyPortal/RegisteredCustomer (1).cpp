#include "RegisteredCustomer.h"
#include "Orders.h"
#include "Feedback.h"
#include<cstring>

RegisteredCustomer::RegisteredCustomer(char cusName[], int cusId)
{
  strcpy(customerName,cusName);
  customerId = cusId;
}
void RegisteredCustomer::setDetails(char cAdd[],int cPho,char cEmail[])
{
  strcpy(address,cAdd);
  phone = cPho;
  strcpy(email,cEmail);
}
int RegisteredCustomer ::getDetails()
{
}
void RegisteredCustomer::addOrder(Order *order)
{
}
void RegisteredCustomer ::login()
{
}
void RegisteredCustomer ::logout()
{
}
void RegisteredCustomer ::searchProducts()
{
}
void RegisteredCustomer ::displayDetails()
{
}
void RegisteredCustomer::displayFeedbackId()
{
}
RegisteredCustomer ::~RegisteredCustomer()
{
}
